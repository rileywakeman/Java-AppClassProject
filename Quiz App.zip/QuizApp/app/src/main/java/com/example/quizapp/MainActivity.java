package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        @Override
        public boolean onOptionsItemSelected(MenuItem item) {
            switch (item.getItemId()) {
                case R.id.action_edit:
                    // User chooses the "Settings" item. Show the app settings UI.
                    return true;

                case R.id.action_edit:
                    // User chooses the "Favorite" action. Mark the current item as a
                    // favorite.
                    return true;

                default:
                    // The user's action isn't recognized.
                    // Invoke the superclass to handle it.
                    return super.onOptionsItemSelected(item);

            }
        }
    }

    private void setSupportActionBar(Toolbar toolbar) {
    }
}