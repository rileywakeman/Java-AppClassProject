package com.example.quizapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        FloatingActionButton fabCreateFolder = findViewById(R.id.fab_create_folder);

        fabCreateFolder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //directory path where you want the folder
                String directoryPath = "/path/to/your/directory/";

                // File name
                String folderName = "NewFolder";

                // directory path + file name
                File folder = new File(directoryPath, folderName);

                // Check if folder name already exists
                if (!folder.exists()) {
                    // Create the folder
                    if (folder.mkdir()) {
                        Toast.makeText(getApplicationContext(), "Folder created successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Failed to create folder", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Folder already exists", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_rename_folder:
                // Renames folder
                renameFolder();
                showRenameDialog();
                return true;
            case R.id.action_delete_folder:
                // Deletes folder
                deleteFolder();
                showDeleteConfirmationDialog();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }



            private void showRenameDialog() {
                // Need code to show a dialog for renaming folder
                // need to put a dialog to input the new folder name or use an EditText in layout.
            }

            private void showDeleteConfirmationDialog() {
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("Are you sure you want to delete this folder?");
                builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // User clicked the "Delete" button, so proceed with folder deletion
                        deleteFolder();
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // User clicked the "Cancel" button, so do nothing
                        dialog.dismiss(); // Dismiss the dialog
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();
            }

            private void deleteFolder() {
                String folderPath = "/path/to/your/folder"; // Replace with the actual folder path
                File folder = new File(folderPath);

                if (folder.exists()) {
                    deleteFolder(folder);
                } else {
                    Toast.makeText(this, "Folder does not exist", Toast.LENGTH_SHORT).show();
                }
            }

            private void deleteFolder(File folder) {
                if (folder.isDirectory()) {
                    File[] files = folder.listFiles();
                    if (files != null) {
                        for (File file : files) {
                            deleteFolder(file); // Recursively delete files and subdirectories
                        }
                    }
                }
                if (folder.exists() && folder.delete()) {
                    Toast.makeText(this, "Folder deleted successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Failed to delete folder", Toast.LENGTH_SHORT).show();
                }
            }

            private void renameFolder() {
                // Implement the code to rename the folder

            }
        }